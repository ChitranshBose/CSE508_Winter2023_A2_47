Ques1. To run question 1 the files are already mounted on drive just need to run the code.

Ques2. To run question 2 just we just need to upload the dataset and execute all the cells.

Ques3. To run question 3 just we just need to upload the dataset and execute all the cells.